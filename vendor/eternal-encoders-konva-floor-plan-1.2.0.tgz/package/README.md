# `@eternal-encoders/konva-floor-plan`

React component that draws a building floor on a Konva stage: rooms, services, an optional route, an optional graph, and an optional GPS marker.

It takes data as props. It does not fetch, save, or read application state. Pass `editor` only in an app that edits the map. Leave it unset for a view-only map.

Published on GitHub Packages as `@eternal-encoders/konva-floor-plan`.

## Install

```
@eternal-encoders:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

`NODE_AUTH_TOKEN` is a GitHub token with `read:packages`. Install the package and these peers: `react`, `react-dom`, `konva`, `react-konva`, `use-image`.

```tsx
import { FloorPlan } from '@eternal-encoders/konva-floor-plan';

<FloorPlan
    floor={{ width, height, rooms, services }}
    schemes={colorSchemes}
    theme="light"
    viewport={{ width: viewportWidth, height: viewportHeight }}
    onRoomSelect={(pointId) => { /* app opens that point */ }}
/>
```

Agent context for this library is in [docs/context/context.md](docs/context/context.md).

## Map behavior (1.1.0)

```tsx
<FloorPlan
    floor={floor}
    schemes={schemes}
    theme="light"
    viewport={viewport}
    gestures={{
        rotationThreshold: 20,
        rotationSensitivity: 1.2,
        rotationSnapRange: 20,
        rotationSnapDuration: 220,
    }}
    background={{ pattern: 'dots-and-lines', color: '#F4F5F7' }}
/>
```

All gesture fields are optional and the example values are the library defaults. The threshold is measured in finger degrees before sensitivity is applied; crossing it consumes that angle without jumping. Active rotation follows the fingers. Within the snap range, releasing an activated gesture eases to the nearest multiple of 90°. Set `rotationSnapRange: 0` to disable attraction and `rotationSnapDuration: 0` for immediate settling. Reduced motion is respected.

Background is optional; omitting it retains scheme rendering. Set `color` for a solid surface and `pattern: 'dots-and-lines'` for the adaptive pattern. Theme defaults are #F4F5F7 (light) and #0F1115 (dark). Apps own theme selection, settings, loading and panels; the library owns canvas drawing and gestures. Label orientation is unchanged in this release.

Build with `pnpm build`, run regression checks with `pnpm test`.

## Adaptive labels and icons (1.2.0)

Pass `annotations={{}}` to enable screen-size limits and upright labels. Omit it to retain authored rendering (for example, in an editor).

```tsx
annotations={{
    text: { minSize: 9, maxSize: 16, fadeStart: 4, fadeEnd: 8, keepUpright: true },
    icons: { minSize: 16, maxSize: 26, fadeStart: 8, fadeEnd: 16, keepUpright: true },
}}
```

Text size is the on-screen font size; icon size is its larger dimension. Between fadeStart and fadeEnd of the original projected size, opacity changes smoothly with zoom. Authored centers stay fixed. Direction signs and stair arrows rotate with the map; override `directionalIcons` with asset names to select these exceptions. Other annotations remain upright. Updates run before Konva drawing, without React frame updates. This reduces clutter at overview scale; overlapping labels are not automatically rearranged.
