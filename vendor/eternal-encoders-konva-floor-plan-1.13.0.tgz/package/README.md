# `@eternal-encoders/konva-floor-plan`

React component that draws a building floor on a Konva stage: rooms, services, an optional route, an optional graph, and an optional GPS marker.

It takes data as props. It does not fetch, save, or read application state. Pass `editor` only in an app that edits the map. Leave it unset for a view-only map.

Published on GitHub Packages as `@eternal-encoders/konva-floor-plan`.

## Install

```
@eternal-encoders:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

`NODE_AUTH_TOKEN` is a GitHub token with `read:packages`. Install the package and these peers: `react`, `react-dom`, `konva`, `react-konva`, `use-image`.

```tsx
import { FloorPlan } from '@eternal-encoders/konva-floor-plan';

<FloorPlan
    floor={{ width, height, rooms, services }}
    schemes={colorSchemes}
    theme="light"
    viewport={{ width: viewportWidth, height: viewportHeight }}
    onRoomSelect={(pointId) => { /* app opens that point */ }}
/>
```

Agent context for this library is in [docs/context/context.md](docs/context/context.md).

## Map behavior (1.1.0)

```tsx
<FloorPlan
    floor={floor}
    schemes={schemes}
    theme="light"
    viewport={viewport}
    gestures={{
        rotationThreshold: 20,
        rotationSensitivity: 1.2,
        rotationSnapRange: 20,
        rotationSnapDuration: 220,
    }}
    background={{ pattern: 'dots-and-lines', color: '#F4F5F7' }}
/>
```

All gesture fields are optional and the example values are the library defaults. The threshold is measured in finger degrees before sensitivity is applied; crossing it consumes that angle without jumping. Active rotation follows the fingers. Within the snap range, releasing an activated gesture eases to the nearest multiple of 90°. Set `rotationSnapRange: 0` to disable attraction and `rotationSnapDuration: 0` for immediate settling. Reduced motion is respected.

Background is optional; omitting it retains scheme rendering. Set `color` for a solid surface and `pattern: 'dots-and-lines'` for the adaptive pattern. Theme defaults are #F4F5F7 (light) and #0F1115 (dark). Apps own theme selection, settings, loading and panels; the library owns canvas drawing and gestures. Label orientation is unchanged in this release.

Build with `pnpm build`, run regression checks with `pnpm test`.

## Adaptive labels and icons (1.2.0)

Pass `annotations={{}}` to enable screen-size limits and upright labels. Omit it to retain authored rendering (for example, in an editor).

```tsx
annotations={{
    text: { minSize: 9, maxSize: 16, fadeStart: 4, fadeEnd: 8, keepUpright: true },
    icons: { minSize: 16, maxSize: 26, fadeStart: 8, fadeEnd: 16, keepUpright: true },
}}
```

Text size is the on-screen font size; icon size is its larger dimension. Between fadeStart and fadeEnd of the original projected size, opacity changes smoothly with zoom. Authored centers stay fixed. Direction signs and stair arrows rotate with the map; override `directionalIcons` with asset names to select these exceptions. Other annotations remain upright. Updates run before Konva drawing, without React frame updates. This reduces clutter at overview scale; overlapping labels are not automatically rearranged.

## Double-tap zoom (1.3.0)

Mobile double taps zoom 2× around the tapped point over 220ms. Configure `gestures.doubleTapScale` and `doubleTapDuration`; use a scale of 1 to disable it. Dragging, long presses and pinch gestures do not count as taps. New input interrupts zoom; reduced motion is respected. Room tap selection is retained.

### One-finger quick zoom (1.3.1)

Double tap and keep the second finger down, then drag down to zoom in or up to zoom out. The map stays anchored at the second tap; release does not add another zoom step. Ordinary short double tap is retained.

## Rotation observer (1.4.0)

Pass `onRotationChange={(degrees) => { /* update an external compass */ }}` to receive the initial/current canvas angle. The library owns no compass permissions or device orientation listeners.

## Relative annotation fade and styling (included in 1.4.0)

`annotations.text` also accepts `fontFamily`, `fontStyle` and `color`. Explicit color supersedes scheme room/type text colors. Both `text` and `icons` accept `fadeThresholdMultiplier`: a positive finite multiplier applied to fadeStart/fadeEnd, default 1; invalid/zero/negative values use 1. It does not change minSize/maxSize. For example, 0.75 turns the default text fade range 4–8px into 3–6px.

See [rendering priority and restoration](docs/context/overrides.md) for what optional props supersede. In particular, removing only background.color does not restore scheme background: omit the entire background prop. The library snap-range default is 20°; the navigator's 25° override is consumer policy.

## Source layout and validation

Implementation lives in the `widgets/floor-plan` FSD slice; the package root preserves its existing public exports. Build emits ESM and TypeScript declarations; React/Konva peers remain external. Run `pnpm test` and `pnpm build`. See [delivery audit](docs/agent/documentation-audit.md) for checked contracts and verification limits. Hardware touch feel and browser-specific rendering require consumer/device checks.


## Active rotation attraction (1.5.0)

Set gestures.rotationSnapDuringGesture to true to attract toward right angles during active rotation. Default false preserves release-only behavior. Uses rotationSnapRange, with exact hold in its inner 20% and a continuous monotone transition outside it; raw finger rotation remains independent. Range 0 disables attraction.


## Search focus (1.6.0)

Optional `focus` accepts pointId, x/y in floor pixels, requestId (increment to repeat the same target), center in viewport pixels, duration (default 300ms) and optional fill/stroke. It moves the camera without changing scale/rotation, respecting drag bounds. New touch/mouse/wheel input cancels movement; reduced motion and duration 0 place it immediately. A matching room.pointId receives the temporary paint override; removing focus restores scheme colors. Consumers own floor/building matching, request lifetime and panel state. Unmapped graph points still receive camera focus but cannot tint a room without a matching pointId.
